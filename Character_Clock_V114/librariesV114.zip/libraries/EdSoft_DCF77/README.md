# EdSoft_DCF77 V1.0.0
Arduino library for DCF77 recepton using no interrupts..

##Functions

@...  2967 30211 09% [0] 00:00|21| 00-00-2000/0 F21 OK:0

## Usage
1. Download zip file
2. In Arduino IDE: Sketch -> Include Library -> Add .ZIP Library
3. Include the library in your project using "#include <EdSoft_DCF77.h>" directive


## Example





